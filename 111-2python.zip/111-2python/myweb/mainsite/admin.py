from django.contrib import admin
from mainsite import models
admin.site.register(models.HBicycleData)
admin.site.register(models.NKUSTnews)
admin.site.register(models.PhoneMaker)
admin.site.register(models.PhoneModel)
admin.site.register(models.StockInfo)
